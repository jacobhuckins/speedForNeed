#import <math.h>
#import <stdio.h>
main(){

